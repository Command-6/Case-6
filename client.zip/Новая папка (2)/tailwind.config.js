/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './page1.html{js,ts,jsx,tsx}',
    './page2.html{js,ts,jsx,tsx}',
    './page3.html{js,ts,jsx,tsx}',
    './global.css{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        montserrat: ['"Montserrat Alternates"', 'sans-serif'],
      },
    },
  },
  plugins: [],
}

