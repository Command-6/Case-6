URL = "http://192.168.0.12:8000/" //IP-адрес бэкэнд-сервера

function downloadBase64(base64Data, filename, mimeType = 'application/octet-stream') {
    // Создаем data URL
    const dataUrl = `data:${mimeType};base64,${base64Data}`;
    
    // Создаем элемент <a> для скачивания файла
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = filename;  // Указываем имя файла для скачивания
    a.style.display = 'none';
    
    // Добавляем элемент на страницу, вызываем клик и удаляем элемент
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

//!!!!!!!!!!!!!!!!

document.getElementById("search_but").addEventListener('click', async function(e) {
    e.preventDefault();
    var books = document.querySelectorAll('#book');
    books.forEach(function(book) {
        book.remove();
    })
    var search = document.getElementById("search_input").value;
    try {
        const response = await fetch(URL + "search_element?search=" + search);
        const items = await response.json();
        const itemsContainer = document.getElementById('cont_books');
        items.forEach(item => {
            // Создаем элемент div для каждого элемента списка
            const itemDiv = document.createElement('div');
            itemDiv.id = "book";
            itemDiv.innerHTML = `
                        <div class="flex flex-row w-1/6 m-12"> 
                <img src="data:image/png;base64,${item.photo}" class="item bg-gray-200"></img> 
                <div class=" ml-4 flex flex-col">
                <h1 class="mt-4">${item.name}</h1>
                <h1 class="mt-4">${item.author}</h1>

                <h1 class="mt-2 w-9">${item.disc}</h1>
                <a href="#" id="${item.id}_txt" 
    class="button text-white px-4 rounded-md  hover:bg-indigo-600 focus:ring-2 focus:ring-indigo-500 border-2 text-center">
    Файл .txt
</a>
<a href="#" id="${item.id}_fb2" 
    class="button text-white px-4  rounded-md  hover:bg-indigo-600 focus:ring-2 focus:ring-indigo-500 border-2 text-center">
    Файл .fb2
</a>
<a href="#" id="${item.id}_docx" 
    class="button text-white px-4  rounded-md  hover:bg-indigo-600 focus:ring-2 focus:ring-indigo-500 border-2 text-center">
    Файл .docx
</a>
                    `;
                    console.log(item.name);
                    itemsContainer.appendChild(itemDiv);
                });

            }
             catch (error) {
                console.error('Ошибка получения данных:', error);
            }
        
        })



document.getElementById("rand__book").addEventListener('click', async function(e) {
    e.preventDefault();
    var books = document.querySelectorAll('#book');
    books.forEach(function(book) {
        book.remove();
    })
    try {
        const response = await fetch(URL + "random_element");
        const items = await response.json();
        const itemsContainer = document.getElementById('cont_books');
         // Пройдемся по каждому элементу и выведем его на страницу
         item = items[0];
            // Создаем элемент div для каждого элемента списка
            const itemDiv = document.createElement('div');
            itemDiv.id = "book";
            itemDiv.innerHTML = `<div class="flex flex-row w-1/6 m-12"> 
                <img src="data:image/png;base64,${item.photo}" class="item bg-gray-200"></img> 
                <div class=" ml-4 flex flex-col">
                <h1 class="mt-4">${item.name}</h1>
                <h1 class="mt-4">${item.author}</h1>

                <h1 class="mt-2 w-9">${item.disc}</h1>
                <a href="#" id="${item.id}_txt" 
    class="button text-white px-4 rounded-md  hover:bg-indigo-600 focus:ring-2 focus:ring-indigo-500 border-2 text-center">
    Файл .txt
</a>
<a href="#" id="${item.id}_fb2" 
    class="button text-white px-4  rounded-md  hover:bg-indigo-600 focus:ring-2 focus:ring-indigo-500 border-2 text-center">
    Файл .fb2
</a>
<a href="#" id="${item.id}_docx" 
    class="button text-white px-4  rounded-md  hover:bg-indigo-600 focus:ring-2 focus:ring-indigo-500 border-2 text-center">
    Файл .docx
</a>
                    `;
                    itemsContainer.appendChild(itemDiv);


    } catch (error) {
        console.error('Ошибка получения данных:', error);
    }
})



async function randomitem(i) {
    try {
        const response = await fetch(URL + "random_element");
        const items = await response.json();

            document.getElementById(`plav_${i+1}`).src = `data:image/png;base64,${items[0].photo}`;
            document.getElementById(`plav_${i+1}1`).src = `data:image/png;base64,${items[0].photo}`

    } catch (error) {
        console.error('Ошибка получения данных:', error);
    }
}

async function fetchItems() {
    try {
        const response = await fetch(URL + "get_elemets");
        const items = await response.json();

        // Найдем контейнер для вывода элементов
        const itemsContainer = document.getElementById('cont_books');
         // Пройдемся по каждому элементу и выведем его на страницу
         items.forEach(item => {
            // Создаем элемент div для каждого элемента списка
            const itemDiv = document.createElement('div');
            itemDiv.id = "book";
            itemDiv.innerHTML = `
                        <div class="flex flex-row w-1/6 m-12"> 
                <img src="data:image/png;base64,${item.photo}" class="item bg-gray-200"></img> 
                <div class=" ml-4 flex flex-col">
                <h1 class="mt-4">${item.name}</h1>
                <h1 class="mt-4">${item.author}</h1>

                <h1 class="mt-2 w-9">${item.disc}</h1>
                <a href="#" id="${item.id}_txt" 
    class="button text-white px-4 rounded-md  hover:bg-indigo-600 focus:ring-2 focus:ring-indigo-500 border-2 text-center">
    Файл .txt
</a>
<a href="#" id="${item.id}_fb2" 
    class="button text-white px-4  rounded-md  hover:bg-indigo-600 focus:ring-2 focus:ring-indigo-500 border-2 text-center">
    Файл .fb2
</a>
<a href="#" id="${item.id}_docx" 
    class="button text-white px-4  rounded-md  hover:bg-indigo-600 focus:ring-2 focus:ring-indigo-500 border-2 text-center">
    Файл .docx
</a>
                    `;
                    console.log(item.name);
                    itemsContainer.appendChild(itemDiv);

                    document.getElementById(`${item.id}_txt`).addEventListener('click', function (e) {
                        e.preventDefault();
                        downloadBase64(item.file_1, `${item.name}.txt`, 'text/plain');  // Задаем имя для скачиваемого файла
                      });
                      document.getElementById(`${item.id}_fb2`).addEventListener('click', function (e) {
                          e.preventDefault();
                          downloadBase64(item.file_2, `${item.name}.fb2`, 'application/x-fictionbook+xml');  // Задаем имя для скачиваемого файла
                        });
                        document.getElementById(`${item.id}_docx`).addEventListener('click', function (e) {
                            e.preventDefault();
                            downloadBase64(item.file_3, `${item.name}.docx`, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');  // Задаем имя для скачиваемого файла
                          });

         });

    }
     catch (error) {
        console.error('Ошибка получения данных:', error);
    }

}

for (var i = 1; i<11; i++)
{
    randomitem(i);
}
document.addEventListener('DOMContentLoaded', function() {
    fetchItems();});
