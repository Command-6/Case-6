URL = "http://192.168.0.12:8000/" //IP-адрес бэкэнд-сервера

document.getElementById("add_book").addEventListener('submit', async function(event) {
    event.preventDefault();  // Останавливаем стандартную отправку формы
    var formData = new FormData();

    const name = document.getElementById("book_name").value;
    const author = document.getElementById("author_name").value;
    const disc = document.getElementById("book_disc").value;

    const file_txt = document.getElementById("txt_file").files[0];
    formData.append('file_1', file_txt);

    const file_fb2 = document.getElementById("fb2_file").files[0];
    formData.append('file_2', file_fb2);

    const file_docx = document.getElementById("docx_file").files[0];
    formData.append('file_3', file_docx);
    console.log(name);
    const photo = document.getElementById("photo_book").files[0];
    formData.append('photo', photo);
    for (let pair of formData.entries()) {
        console.log(pair[0] + ': ' + pair[1]);
    }
    try {
        const response = await fetch(URL + "create_element?name=" + name + "&author=" + author + "&disc="+ disc, {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            throw new Error('Ошибка сети');
        }
        const result = await response.json();
        console.log('Успешно загружено:', result);

    }
    catch (error) {
        console.error('Ошибка при загрузке файлов:', error);
    }
});